from utils.imglib import *
from utils.plotlib import *
from keras.preprocessing import image
import random
import cv2

data_dir = 'danboogu'
batch_size = 32
img_height, img_width = 256,256
img_files = None
new_dir = 'Dataset'
os.makedirs(new_dir)
img_files = [f for f in os.listdir(data_dir) if os.path.isfile(os.path.join(data_dir, f))]
for file in img_files:
  img = cv2.imread(os.path.join(data_dir,file))
  #img_2 = cv2.cvtColor(img_1,cv2.COLOR_RGB2BGR)
  img = cv2.resize(img, (img_width,img_height))
  img.imwrite(os.path.join(new_dir,file),img)
